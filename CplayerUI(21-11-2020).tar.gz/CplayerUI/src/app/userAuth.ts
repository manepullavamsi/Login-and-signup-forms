
// User Authentication model class
export class UserAuth{
    username: string;
    password: string;
    cpassword:string;
}
 

