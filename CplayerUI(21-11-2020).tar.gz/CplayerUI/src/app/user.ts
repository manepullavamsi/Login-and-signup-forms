
 // user model class
export class User{
    username: string;
    name: string;
    image: string;
    mobile: string;
  }

