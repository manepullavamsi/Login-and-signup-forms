export class Favs {
    username: string;
    pid: number;
    country: string;
    name: string;
    fullName: string;
    majorTeams: string;
    currentAge: string;
    imageURL: string;
    playingRole: string;
    status: Boolean;
 }
 // Model class to store the favourites with the attributes