export class Find {
    pid: string;
    name: string;
    fullName: string;
    status: boolean;
  }
  // model class to save the data we are getting from search by name